package com.example.reply.test

annotation class TestCompactWidth
annotation class TestMediumWidth
annotation class TestExpandedWidth
